#!/bin/bash


zip_name="magisk-nethunter-module-for-OP5and5T.zip"
rm $zip_name

cp /home/simonpunk/Downloads/nethunter-app-release-Pie.apk /home/simonpunk/Desktop/magisk-module-nethunter/apps/nethunter.apk
cp /home/simonpunk/Desktop/nethunter-terminal-simonpunk/term/release/term-release.apk /home/simonpunk/Desktop/magisk-module-nethunter/apps/Term-nh.apk

zip -r9 $zip_name * -x $zip_name compile.sh

cp $zip_name /home/simonpunk/Desktop/complied_nethunter/Pie/$zip_name
