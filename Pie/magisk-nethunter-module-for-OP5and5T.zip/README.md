# Magisk Installer

**Update `README.md` if you want to submit your module to the online repo!**

For more information about how to use this module installer, please refer to [documentations](https://topjohnwu.github.io/Magisk/guides.html)

If you are not familiar with the Markdown syntax, you can start by experimenting on GitHub's online Markdown editor, which will let you preview before publishing. If you need more help, the [Markdown Cheat Sheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet) will be handy.
