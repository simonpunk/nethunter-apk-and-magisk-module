#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

log -t userinit "Symlinking Kali boot scripts"
ln -s /data/data/com.offsec.nethunter/files/scripts/bootkali $MODDIR/system/bin/bootkali
ln -s /data/data/com.offsec.nethunter/files/scripts/bootkali_init $MODDIR/system/bin/bootkali_init
ln -s /data/data/com.offsec.nethunter/files/scripts/bootkali_env $MODDIR/system/bin/bootkali_env
ln -s /data/data/com.offsec.nethunter/files/scripts/bootkali_login $MODDIR/system/bin/bootkali_login
ln -s /data/data/com.offsec.nethunter/files/scripts/chrootmgr $MODDIR/system/bin/chrootmgr
ln -s /data/data/com.offsec.nethunter/files/scripts/killchrootmgr $MODDIR/system/bin/killchrootmgr
ln -s /data/data/com.offsec.nethunter/files/scripts/killkali $MODDIR/system/bin/killkali

log -t userinit "Symlinking busybox applets"

if [ -x /system/bin/busybox ]; then
	busybox=/system/bin/busybox
else
	busybox=/sbin/.magisk/mirror/bin/busybox
fi

[ ! -x /system/bin/busybox ] && $busybox ln -sf $busybox /system/bin/busybox

for applet in `$busybox --list`; do
	if [ ! "$applet" = "su" ]; then
		$busybox ln -sf $busybox /system/bin/$applet
	fi
done
